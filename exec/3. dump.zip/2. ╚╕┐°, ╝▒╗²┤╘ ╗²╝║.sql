-- 선생님 생성
INSERT INTO jutopia.teacher (id, teacher_id, teacher_pwd, teacher_name, teacher_email, school, grade, classroom) VALUES (UUID(), 'admin1', 'admin1', '선생님', '싸피초등학교', 6, 1);

-- 학생 생성 (싸피초등학교 6 학년 1반 UUID 를 참조)
INSERT INTO jutopia.student (id, student_id, student_pwd, student_name, school, grade, class_room, student_number, classroom_id, money, point) VALUES (UUID(), 'test1', 'test1', '임준환', '싸피초등학교', 6, 1, 1, '싸피초등학교 6학년 1반 UUID 참조', 1000000, 0); 
INSERT INTO jutopia.student (id, student_id, student_pwd, student_name, school, grade, class_room, student_number, classroom_id, money, point) VALUES (UUID(), 'test2', 'test2', '김도훈', '싸피초등학교', 6, 1, 2, '싸피초등학교 6학년 1반 UUID 참조', 1000000, 0);
INSERT INTO jutopia.student (id, student_id, student_pwd, student_name, school, grade, class_room, student_number, classroom_id, money, point) VALUES (UUID(), 'test3', 'test3', '김현종', '싸피초등학교', 6, 1, 3, '싸피초등학교 6학년 1반 UUID 참조', 1000000, 0);
INSERT INTO jutopia.student (id, student_id, student_pwd, student_name, school, grade, class_room, student_number, classroom_id, money, point) VALUES (UUID(), 'test4', 'test4', '김기홍', '싸피초등학교', 6, 1, 4, '싸피초등학교 6학년 1반 UUID 참조', 1000000, 0);
INSERT INTO jutopia.student (id, student_id, student_pwd, student_name, school, grade, class_room, student_number, classroom_id, money, point) VALUES (UUID(), 'test5', 'test5', '신성주', '싸피초등학교', 6, 1, 5, '싸피초등학교 6학년 1반 UUID 참조', 1000000, 0);
INSERT INTO jutopia.student (id, student_id, student_pwd, student_name, school, grade, class_room, student_number, classroom_id, money, point) VALUES (UUID(), 'test6', 'test6', '소영섭', '싸피초등학교', 6, 1, 6, '싸피초등학교 6학년 1반 UUID 참조', 1000000, 0);
