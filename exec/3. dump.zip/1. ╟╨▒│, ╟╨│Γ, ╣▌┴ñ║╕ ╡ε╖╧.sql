-- 학교 생성
INSERT INTO schooldb.school (school_id, region, school_code, school_name) VALUES (UUID(), '광주 광산구', 'SSAFY', '싸피초등학교');

-- 학년 생성 (싸피초등학교 UUID 를 참조)
INSERT INTO schooldb.grade (grade_id, grade_account_init_point, grade_account_point, grade_num, school_id) VALUES (UUID(), 1000000, 1000000, 1, '방금 생성한 학교 uuid'); 
INSERT INTO schooldb.grade (grade_id, grade_account_init_point, grade_account_point, grade_num, school_id) VALUES (UUID(), 1000000, 1000000, 2, '방금 생성한 학교 uuid');
INSERT INTO schooldb.grade (grade_id, grade_account_init_point, grade_account_point, grade_num, school_id) VALUES (UUID(), 1000000, 1000000, 3, '방금 생성한 학교 uuid');
INSERT INTO schooldb.grade (grade_id, grade_account_init_point, grade_account_point, grade_num, school_id) VALUES (UUID(), 1000000, 1000000, 4, '방금 생성한 학교 uuid');
INSERT INTO schooldb.grade (grade_id, grade_account_init_point, grade_account_point, grade_num, school_id) VALUES (UUID(), 1000000, 1000000, 5, '방금 생성한 학교 uuid');
INSERT INTO schooldb.grade (grade_id, grade_account_init_point, grade_account_point, grade_num, school_id) VALUES (UUID(), 1000000, 1000000, 6, '방금 생성한 학교 uuid');

-- 반 생성 (6학년 UUID를 참조)
INSERT INTO schooldb.classroom (classroom_id, bank_name, capital_gains_tax, class_money, class_num, consumption_tax_rate, exchange_tax_rate, init_money, money_code, money_name, total_money, trade_tax_rate, grade_id) VALUES (UUID(), '광주1반은행', 10.5, 10000000, 1, 3.3, 2.4, 10000000, 'GW1', '광주1코인', 10000000, 3.9, '6학년  grade uuid');
INSERT INTO schooldb.classroom (classroom_id, bank_name, capital_gains_tax, class_money, class_num, consumption_tax_rate, exchange_tax_rate, init_money, money_code, money_name, total_money, trade_tax_rate, grade_id) VALUES (UUID(), '광주2반은행', 10.5, 10000000, 2, 3.3, 2.4, 10000000, 'GW2', '광주2코인', 10000000, 3.9, '6학년  grade uuid');

-- 적금 상품 생성 (1반 UUID를 참조)
INSERT INTO schooldb.savingproducts (saving_products_id, interest_rate, max_money, min_money, term, classroom_id, product_detail, product_name) VALUES (UUID(), 7.7, 10000, 1000, 12, '1반 UUID를 참조', '양 많이 요청하면 양 많이 줌', '양많이요~~');